:- module(solve, [solve/2]).

:- use_module(library(clpfd)).
:- use_module(library(lists), [append/3]).
:- use_module(numvars, [sym_melt/3, diff_vars/2, melt/2, varname/1]).
:- use_module(aux, [writel/1]).
:- use_module(simplify_symb, [simplify_symb/2]).

solve(C,D) :- !,
	sym_melt(C,MC,D),
	diff_vars(MC, Vs_),
	gr_eq(Vs_, Vs),
	%%%%aux:writel(Vs),
	
	solve1(MC, Rest),
	%write('**1**'),nl,
	%%aux:writel(Rest),
	%%%labeling([],Vs),
	Vs = [1,0,0,1],
	write('Trying '), write(Vs), nl,
	write(D), nl,
	%%aux:writel(Rest),
	simplify_l(Rest, Rest1),
	%%aux:writel(Rest1),
	melt(Rest1,MRest),
	solve2(MRest),
	filter(D),nl.

gr_eq([],[]).
gr_eq([V|Vs],VVs):-
	\+ var(V),
	varname(V),!,
	gr_eq(Vs,VVs).
gr_eq([V|Vs],[V|VVs]):-
	V in 0..1,
	gr_eq(Vs,VVs).

% first of all consider comparisons that do not depend on '#VAR'-iables
solve1([],[]).
solve1([true|Xs], Ys):-
	!, solve1(Xs, Ys).
solve1([X|Xs], Ys):-
	check(X),
	!, X,
	solve1(Xs, Ys).
solve1([X|Xs], [X|Ys]):-
	solve1(Xs, Ys).


check(X):- var(X), !.
check(X):- number(X), !.
check(X):-
	compound(X),
	X =.. [_,Y,Z],
	check(Y), check(Z).


simplify_l([], []).
simplify_l([X|Xs], [SX|SXs]):-
	simplify_symb(X,SX),!,
	simplify_l(Xs, SXs).

solve2(true).
solve2([]).
solve2([sqr_ineq(A,B,C,Min,Max,Op)|Xs]):-
	!,
	sqr_ineq(A,B,C,Min,Max,Op),
	solve2(Xs).
solve2((Exp,Exps)):-
	solve2([Exp]),
	solve2(Exps).
solve2([(Exp,Exps)|Expss]):-
	solve2([Exp]),
	solve2(Exps),
	solve2(Expss).
solve2([X<Y|Xs]):-
	X #< Y, !,
	solve2(Xs).
solve2([X=<Y|Xs]):-
	X #=< Y, !,
	solve2(Xs).
solve2([X>Y|Xs]):-
	X #> Y, !,
	solve2(Xs).
solve2([X>=Y|Xs]):-
	X #>= Y, !,
	solve2(Xs).
solve2([X=Y|Xs]):-
	X #= Y, !,
	solve2(Xs).


filter(X):- var(X),!.
filter(dict(_Var,0,Left,Right)):-
	filter(Left), filter(Right).
filter(dict(Var,1,Left,Right)):-
	write((Var,1)),nl,
	filter(Left), filter(Right).

sqr_ineq(A,B,C,_,_,Op):-
	writel([A,B,C]), nl,
	write('Case 1'), nl,E1 =.. [#=, A, 0], E1,
	write('Case 1 After A#=0'), nl,
	E2 =.. [#=, B, 0], E2, !, E =.. [Op,C,0], E.
sqr_ineq(A,B,C,Min,_,Op):-
	write('Case 2'), nl,E1 =.. [#=, A, 0], E1,
	write('Case 2 After A#=0'), nl,
	E2 =.. [#>, B, 0], E2, !,
	E =.. [Op,-C/B,Min], E.
sqr_ineq(A,B,C,_,Max,Op):-
	write('Case 3'), nl,E1 =.. [#=, A, 0], E1,
	write('Case 3 After A#=0'), nl,E2 =.. [#<, B, 0], E2, !,
	E =.. [Op,Max,-C/B], E.
sqr_ineq(A,B,C,_,_,_):-
	write('Case 4'), nl,E1 =.. [#>, A, 0], E1,
	write('Case 4 After A#>0'), nl,
	E2 =.. [#<, B*B-4*A*C, 0], E2.
sqr_ineq(A,B,C,_Min,_Max,#=<):-
	write('Case 5'), nl,E1 =.. [#>, A, 0], E1,
	E2 =.. [#=, B*B-4*A*C, 0], E2.
sqr_ineq(A,B,C,_Min,Max,Op):-
	write(Op),nl,
	write('Case 6'), nl,
	E1 =.. [#>, A, 0], E1,
	write('Case 6 After A#>0'), nl,
	E2 =.. [#>, B*B-4*A*C, 0], E2,
	write('Case 6 After Discriminant'),nl,
	X1 is ceiling(-B-sqrt(B*B-4*A*C)/(2*A)),
	%%% use of ceiling does not help
	%%% E3 =.. [#=, X1, (-B-sqrt(B*B-4*A*C)/(2*A))], E3,
	write('Case 6 After X1'), nl,
	write(X1), nl, write(Max),nl,
	E =.. [Op, X1, Max], E,
	write('Case 6 After E'), nl.
sqr_ineq(A,B,C,Min,_Max,Op):-
	write('Case 7'), nl, E1 =.. [#>, A, 0], E1,
	write('Case 7 After A#>0'), nl,
	E2 =.. [#>, B*B-4*A*C, 0], E2,
	write('Case 7 After Discriminant'),nl,
	X2 is (-B+sqrt(B*B-4*A*C)/(2*A)),
	E =.. [Op, Min, X2], E.
sqr_ineq(A,B,C,Min,Max,Op):-
	write('Case 8'), nl,
	E1 =.. [#<, A, 0], E1, write('Case 8 After A#>0'), nl,
	E2 =.. [#>=, B*B-4*A*C, 0], E2, write('Case 8 After Discriminant'),nl,
	X1 is (-B-sqrt(B*B-4*A*C)/(2*A)),
	X2 is (-B+sqrt(B*B-4*A*C)/(2*A)),
	E1 =.. [Op,Min,X1], E1,
	E2 =.. [Op,X2,Max], E2.
