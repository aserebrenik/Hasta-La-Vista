:- module(simplify_symb, [combine/2,simplify_symb/2]).
:- use_module(numvars, [varname/1]).
:- use_module(comma, [remove_trues/2]).
:- use_module(library(lists), [is_list/1]).
:- use_module(library(ordsets), [is_ordset/1, list_to_ord_set/2,ord_union/3]).

eq(and(I,I),I).
eq(and(A, true), A).
eq(and(true, A), A).
eq(X+0,X).
eq(0+X,X).
eq(_X*0,0).
eq(0*_X,0).
eq(X*1,X).
eq(1*X,X).
eq(X+X*(-1),0).
eq(X*(-1)+X,0).
eq((B*C), D):- number(B), number(C), D is B*C.
eq((B+C), D):- number(B), number(C), D is B+C.			
eq((A*B)*C,A*(B*C)).
eq(A*(B+C),A*B+A*C). %%%% :- \+ varname(A).
%%%%%%% eq(A*B+A*C,A*(B+C)) :- varname(A).
eq((A+B)*C,A*C+B*C).
eq(A-B, A+B*(-1)).

simplify_symb(Exp,SExp):-
	eq(Exp,NExp),!,
	simplify_symb(NExp,SExp).
simplify_symb(implies(Body,BuiltIns,Head),
	      implies(Body1,BuiltIns1,Head1)) :-
	!, simplify_symb(Body,Body1),
	remove_trues(BuiltIns, BuiltIns1),
	simplify_symb(Head,Head1).
simplify_symb(-S, SExp):-
	simplify_symb(S*(-1),SExp).
simplify_symb(S,SExp):-
	S =.. [Op,X,Y],
	simplify_symb(X,SX),
	simplify_symb(Y,SY),
	\+ ((X,Y) = (SX,SY)), !,
	S1 =.. [Op, SX, SY],
	simplify_symb(S1,SExp).
simplify_symb(Exp,Exp).




combine(Pos, Positions):-
	keysort(Pos, Pos1),
	combine_(Pos1,Positions).
combine_([],[]).
combine_([Pred-Pos1, Pred-Pos2|Pos], Positions):-
	is_list(Pos1), !,
	to_ordset(Pos1, Pos11),
	to_ordset(Pos2, Pos21),
	ord_union(Pos11,Pos21,Pos3),
	combine_([Pred-Pos3|Pos], Positions).
combine_([Pred-Pos1, Pred-Pos2|Pos], Positions):-
	simplify_symb(Pos1+Pos2,Pos3),
	combine_([Pred-Pos3|Pos], Positions).
combine_([Pred-Pos1|Pos], [Pred-Pos1|Positions]):-
	combine_(Pos, Positions).
to_ordset(OrdSet, OrdSet):-
	is_ordset(OrdSet), !.
to_ordset(List, OrdSet):-
	list_to_ord_set(List, OrdSet).