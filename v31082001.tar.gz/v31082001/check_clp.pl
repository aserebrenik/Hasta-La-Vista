:- module(check_clp, [check_clp/1]).
:- use_module(library(clpq)).

check_clp(X):-
	copy_term(X,Y), check_clp_(Y).

check_clp_(true) :- !.
check_clp_(false) :- fail.
check_clp_((_X,-inf,inf)):-!.
check_clp_((X,Min,inf)):- !, {X >= Min}.
check_clp_((X,-inf,Max)):- !, {X =< Max}.
check_clp_((X,Min,Max)):- {X >= Min, X =< Max}.
check_clp_(X is Y) :- {X = Y}.
check_clp_(X = Y)  :- {X = Y}.
check_clp_(X > Y)  :- {X > Y}.
check_clp_(X >= Y) :- {X >= Y}.
check_clp_(X < Y)  :- {X < Y}.
check_clp_(X =< Y) :- {X =< Y}.
check_clp_(and(X1,X2)):-
	check_clp_(X1), check_clp_(X2).
check_clp_(or(X1,_X2)):-
	check_clp_(X1), !.
check_clp_(or(_X1,X2)):-
	check_clp_(X2), !.
check_clp_(not(X1)):-
	\+ check_clp_(X1).