:- module(find_int_pos, [find_int_pos/2]).
:- use_module(atom, [fresh_all/2]).
:- use_module(simplify_symb, [combine/2]).
:- use_module(library(lists), [append/3]).
:- use_module(library(ordsets), [list_to_ord_set/2, ord_union/3]).
:- use_module(numvars, [frz/2, varname/1]).

%%% in fact we are interested in finding those arg positions that
%%% participate in some integer computation...
%%% thats why we ignore comparisons, simple integer values etc.

find_int_pos(Clauses,Positions):-
	find_int_pos_(Clauses,Pos),
	combine(Pos, Positions).
find_int_pos_([],[]).
find_int_pos_([clause(Head,Body)|Clauses],
	      [(HeadF-Positions1)|Positions2]) :-
	fresh_all(Head, HeadF),
	copy_term((Head,Body), (Head1,Body1)),
	find_int_body(Head1, Body1, Positions),
	list_to_ord_set(Positions,Positions1),
	find_int_pos_(Clauses, Positions2).
	
find_int_args(_, [], []).
find_int_args(I, [Arg|Args], [I|Positions]):-
	integer(Arg),!, I1 is I+1,
	find_int_args(I1, Args, Positions).
find_int_args(I, [_Arg|Args], Positions):-
	I1 is I+1,
	find_int_args(I1, Args, Positions).

find_int_body(_, true, []).
find_int_body(Head, (X is Y,B2), Positions):-
	!, frz((X is Y), (FX is FY)),
	(X is Y) = (FX is FY),
	Head =.. [_|Args],
	find_var_args(Args,1,VarArgs),
	find_int_body(Head, B2, Positions0),
	append(VarArgs,Positions0,Positions).
find_int_body(Head,(_B1,B2), Positions):-
	find_int_body(Head,B2, Positions).

find_var_args([], _, []).
find_var_args([A|Args],I,[I|Positions]):-
	varname(A), !, I1 is I+1,
	find_var_args(Args, I1, Positions).
find_var_args([_A|Args],I,Positions):-
	I1 is I+1, find_var_args(Args, I1, Positions).
	