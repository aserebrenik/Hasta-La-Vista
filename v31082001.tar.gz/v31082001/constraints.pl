% BAD DOES NOT WORK


:- module(constraints, [simplify/2]).

:- use_module(aux, [time/1, timer/1]).

less(-inf,_X):-!.
less(_X,inf):-!.
less(X,Y):- X < Y.

eq((-inf,-inf), false).
eq((inf, inf), false).
eq((-inf, inf), true).

eq(not(X<Y), X>Y).
eq(not(X=<Y), X>=Y).
eq(not(X>Y), X<Y).
eq(not(X>=Y), X=<Y).
eq(or(X<Y,X>=Y), true).
eq(or(X=<Y,X>Y), true).
eq(or(X>Y,X=<Y), true).
eq(or(X>=Y,X<Y), true).
eq(and(X<Y,X<Z), X<Y):- ground(Z), ground(Y), Z >= Y,!.
eq(and(X<Y,X<Z), X<Z):- ground(Z), ground(Y), Y > Z,!.
eq(and(X<Y,X>Z), false):- ground(Z), ground(Y), Z >= Y,!.
eq(and(X>Y,X<Z), false):- ground(Z), ground(Y), Y >= Z,!.
eq(and(X>=Y,X>=Z), X>=Z):- ground(Z), ground(Y), Z >= Y,!.
eq(and(X>=Y,X>=Z), X>=Y):- ground(Z), ground(Y), Y > Z,!.
eq(and(X=<Y,X=<Z), X=<Y):- ground(Z), ground(Y), Z >= Y,!.
eq(and(X=<Y,X=<Z), X=<Z):- ground(Z), ground(Y), Y > Z,!.
eq(and(X=<Y,X>=Z), false):- ground(Z), ground(Y), Z > Y,!.
eq(and(X>=Y,X=<Z), false):- ground(Z), ground(Y), Y > Z,!.
eq(and(X>=Y,X>=Z), X>=Z):- ground(Z), ground(Y), Z >= Y,!.
eq(and(X>=Y,X>=Z), X>=Y):- ground(Z), ground(Y), Y >= Z,!.

eq(not(true,false)).
eq(not(false,true)).
eq(not(and(I1,I2)),or(not(I1),not(I2))).
eq(not(or(I1,I2)),and(not(I1),not(I2))).
eq(or(false,A),A).
eq(or(A,false),A).
eq(or(true,_A), true).
eq(or(_A,true), true).
eq(or(I,I),I).
eq(or(X,or(X,Y)), or(X,Y)).
eq(or(X,or(Y,X)), or(X,Y)).
eq(or(or(X,Y),X), or(X,Y)).
eq(or(or(Y,X),X), or(X,Y)).
eq(and(I,I),I).
eq(and(_A, false), false).
eq(and(false, _A), false) :- !.
eq(and(A, true), A).
eq(and(true, A), A) :- !.
eq(and(A,or(B,C)),or(and(A,B),and(A,C))).
eq(and(or(B,C),A),or(and(A,B),and(A,C))).
eq(and(X,and(X,Y)), and(X,Y)) :- !.
eq(and(X,and(Y,X)), and(X,Y)) :- !.
eq(and(and(X,Y),X), and(X,Y)) :- !.
eq(and(and(Y,X),X), and(X,Y)) :- !.
eq(and(X,and(Y,Z)),and(and(X,Y),and(X,Z))) :-
	\+ functor(X,and,2).

eq(and(and(X,Y),and(Z,U)),and(X,Y)):- ground(

simplify(X>Y,X>Y):-!.
simplify(X>=Y,X>=Y):-!.
simplify(X<Y,X<Y):-!.
simplify(X=<Y,X=<Y):-!.
simplify(Exp,SExp):-
	eq(Exp,NExp),!,
	simplify(NExp,SExp).
simplify(and(X,Y),SExp):-
	simplify(X,SX),
	simplify(Y,SY),
	\+ (SX,SY) = (X,Y),!,
	simplify(and(SX,SY),SExp).
simplify(or(X,Y),SExp):-
	simplify(X,SX),
	simplify(Y,SY),
	\+ (SX,SY) = (X,Y),!,
	simplify(or(SX,SY),SExp).
simplify(Exp,Exp).



partition(Intervals, Partition) :-
	findall(Part, pick_up(Intervals, true, Part), Partition).

pick_up([], Part, Part).
pick_up([I,J|Is], Exp, Part):-
	simplify(and(and(I,J),Exp),L),
	(L = false -> fail;
	    pick_up(Is, L, Part)).
pick_up([I,J|Is], Exp, Part):-
	simplify(and(not(and(I,J)),Exp),L),
	(L = false -> fail;
	    pick_up(Is, L, Part)).


gen_test(N, Partition):-
	gen_test(1,N,_X,Intervals),!,
	time(_),
	partition(Intervals, Partition),
	timer('Partitioning with findall ').

gen_test(I,N,_,[]) :- I >= N-I+1.
gen_test(I,N,X,[X>=I,X=<NI|Intervals]):-
	NI is N-I+1,I1 is I+1,
	gen_test(I1, N, X, Intervals).

