p(a).
p(b).
p(c).
p(d).

q(Y):-
	p(X),  fail.