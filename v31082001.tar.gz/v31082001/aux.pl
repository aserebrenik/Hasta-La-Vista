:- module(aux, [all_but_nth/4,all_but_nth0/4,
		assert_list/2, eliminate_duplicates/2,
		flatten/2, id_member/2,
		my_ord_subtract/3, my_ord_del_element/4, rename/4, 
		time/1, timer/1, up_to_n/2, without_last/2,
		writel/1, write_quoted/1]).

:- use_module(library(lists), [is_list/1]).

all_but_nth(1, [_|T], V, [V|T]).
all_but_nth(N, [H|T1], V, [H|T2]):-
	N > 1, N1 is N-1,
	all_but_nth(N1, T1, V, T2).
all_but_nth0(0, [_|T], V, [V|T]).
all_but_nth0(N, [H|T1], V, [H|T2]):-
	N > 0, N1 is N-1,
	all_but_nth0(N1, T1, V, T2).

assert_list(_,[]).
assert_list(F,[H|T]):-
	A=..[F,H],
	/*(user:A ->
	    true
	;
	  */  assertz(user:A) %)
	  ,
	assert_list(F,T).



% eliminates repetitions from the list. f(X) and f(Y) are considered
% to be repetitions
eliminate_duplicates([],[]).
eliminate_duplicates([H|Elements], [H|Elements1]):-
	eliminate_duplicates(Elements, H, Elements1).
eliminate_duplicates([],_,[]).
eliminate_duplicates([H|T],H,L):-
	!, eliminate_duplicates(T,H,L).
eliminate_duplicates([X|T],_H,[X|L]):-
	eliminate_duplicates(T,X,L).

% flatten gets a recursive list and returns the non-list elements in it.
% for instance  flatten([1,[2,[3,4]],[5,[6,7]]],L)  returns
% L = [1,2,3,4,5,6,7] 

flatten(Xs,Ys) :- flatten_dl(Xs,d(Ys,[])).
flatten_dl([],d(Xs,Xs)).
flatten_dl([X|Xs],d(Ys,Zs)) :-
   flatten_dl(X,d(Ys,Ys1)),flatten_dl(Xs,d(Ys1,Zs)).
flatten_dl(X,d([X|Xs],Xs)) :- \+is_list(X), X\==[].

id_member(X, [Y|_Ys]):- X == Y.
id_member(X, [_Y|Ys]):- id_member(X, Ys).

% following predicates are similar to ord_subtract and ord_del_element
% however, they remove element if it can be unified with the specified
% element (my_ord_del_element) or with an element of the specified list
% (my_ord_subtract)
my_ord_subtract(OrdSet, [], OrdSet).
my_ord_subtract(OrdSet, [E1|List], NewOrdSet):-
	my_ord_del_element(OrdSet,E1, OrdSet1, _),
	my_ord_subtract(OrdSet1, List, NewOrdSet).

my_ord_del_element([], _, [], []).
my_ord_del_element([El1|List], El2, OrdSet, [El1|List1]):-
	coincide(El1,El2),	  
	!, my_ord_del_element(List, El2, OrdSet, List1).
my_ord_del_element([X|List], El, [X|OrdSet], List1):-
	my_ord_del_element(List, El, OrdSet, List1).

coincide(E1,E2):-
	copy_term(E1,E11), copy_term(E2,E21), E11 = E21.

% rename(Old,New,OldTerm,NewTerm)
rename(Old,New,OldTerm,NewTerm):-
	OldTerm =.. OldList,
	rename_(Old,New,OldList,NewList),
	NewTerm =.. NewList.
rename_(_, _, [], []).
rename_(Old,New,[Old|OldList],[New|NewList]):-!,
	rename_(Old,New,OldList,NewList).
rename_(Old,New,[V|OldList],[NV|NewList]):-
	compound(V), !,
	rename(Old,New,V, NV), 
	rename_(Old,New,OldList,NewList).
rename_(Old,New,[V|OldList],[V|NewList]):-
	rename_(Old,New,OldList,NewList).

% information for timing
time(T) :- statistics(runtime,[_,Tmillisec]), T is Tmillisec/1000.

% debug predicate
timer(X) :- time(T),write(X),write(' '),write(T),nl.

up_to_n(N,L):- up_to_n(1,N,L).
up_to_n(I,N,[I|L]):-
	I =< N, !, I1 is I+1, up_to_n(I1,N,L).
up_to_n(_,_,[]).


without_last([X,_],[X]).
without_last([H|T],[H|T1]):- without_last(T,T1).

writel([]):- write('***********'), nl, nl.
writel([H|T]):- write(H), nl, writel(T).

write_quoted(L):-
	write('['), write_quoted_(L).
write_quoted_([H]) :- !,
	write(''''), write(H), write(''''), write(']').
write_quoted_([H|T]) :-
	write(''''), write(H), write(''''), write(', '),
	write_quoted_(T).