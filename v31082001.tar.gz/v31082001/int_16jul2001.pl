:- module(intervals, [interval_to_conjunct/2,partition/2,
		      to_intervals/2, simplify/2]).

:- use_module(library(lists), [append/3]).

%% used for testing and debugging
:- use_module(library(random), [random/3]).
:- use_module(aux, [time/1, timer/1]).
%%

:- use_module(numvars, [varname/1, vars/2]).

%%% (Min,Max) stays for [Min,Max], i.e., Min =< X =< Max

less(-inf,_X):-!.
less(_X,inf):-!.
less(X,Y):- X < Y.

eq((_,-inf,-inf), false).
eq((_,inf, inf), false).
eq((_,-inf, inf), true).

% intervals
eq(not((_X,-inf, inf)), false) :- !.
eq(not((_X,-inf, -inf)), true) :- !.
eq(not((_X,inf, inf)), true) :- !.
eq(not((X,Min,inf)), (X, -inf, Min1)):- !, Min1 is Min - 1.
eq(not((X,-inf,Max)), (X, Max1, inf)):- !, Max1 is Max + 1.
eq(not((X,Min,Max)),or((X,-inf,Min1),(X,Max1,inf))) :-
	Min1 is Min - 1, Max1 is Max + 1.
eq(or((X,A,B),(X,B,C)),(X,A,C)).
eq(and((X,A,_B),(X,_C,D)),false):- less(D,A), !.
eq(and((X,_A,B),(X,C,_D)),false):- less(B,C), !.
eq(and((X,A,B),(X,C,D)),(X,Z,T)):-
	(less(A,C) -> Z=C; Z=A),!,
	(less(D,B) -> T=D; T=B).

% logic, general
eq(not(true),false).
eq(not(false),true).
eq(not(and(I1,I2)),or(not(I1),not(I2))).
eq(not(or(I1,I2)),and(not(I1),not(I2))).
eq(or(false,A),A).
%% eq(or(A,false),A).
eq(or(true,_A), true).
%% eq(or(_A,true), true).
eq(or(I,I),I).
eq(or(A,and(A,B)), A) :- !.
%% eq(or(A,and(B,A)), A) :- !.
%% eq(or(and(A,B),A), A) :- !.
%% eq(or(and(B,A),A), A) :- !.

eq(or(A,B), or(B,A)):-!.

eq(and(I,I),I).
eq(and(_A, false), false).
eq(and(false, _A), false).
eq(and(A, true), A).
eq(and(true, A), A).
eq(and(A,or(A,B)), A) :- !.
eq(and(A,or(B,A)), A) :- !.
eq(and(or(A,B),A), A) :- !.
eq(and(or(B,A),A), A) :- !.

eq(and(A,or(B,C)),or(and(A,B),and(A,C))).
eq(and(or(B,C),A),or(and(A,B),and(A,C))).
eq(and(I, and(J,K)), and(J,K)):-
	subterm(I, and(J,K)).

% comparisons
eq(not(X=Y), or(X<Y, X>Y)).
eq(not(X<Y), X>=Y).
eq(not(X=<Y), X>Y).
eq(not(X>Y), X=<Y).
eq(not(X>=Y), X<Y).
eq(or(X<Y,X>=Y), true).
eq(or(X=<Y,X>Y), true).
eq(or(X>Y,X=<Y), true).
eq(or(X>=Y,X<Y), true).
eq(and(X<Y,X>=Y), false).
eq(and(X>Y,X=<Y), false).
eq(and(X=<Y,X>Y), false).
eq(and(X>=Y,X<Y), false).
eq(and(X>Y,X<Y), false).
eq(and(X<Y,X>Y), false).

simplify((X,Min,Max),(X,Min,Max)):-!.
simplify(Exp,SExp):-
	eq(Exp,NExp),!,
	simplify(NExp,SExp).
simplify(and(X,Y),SExp):-
	simplify(X,SX),
	simplify(Y,SY),!,
	((SX,SY) = (X,Y) -> SExp = and(X,Y)
	;
	    simplify(and(SX,SY),SExp)).
simplify(or(X,Y),SExp):-
	simplify(X,SX),
	simplify(Y,SY),!,
	((SX,SY) = (X,Y) -> SExp = or(X,Y)
			    ;
	    simplify(or(SX,SY),SExp)).
simplify(Exp,Exp).

intervals_to_partition(Intervals, Partition) :-
	findall(Part, pick_up(Intervals, true, Part), Partition).

pick_up([], Part, Part).
pick_up([I|Is], Exp, Part):-
	simplify(and(I,Exp),L),
	(L = false -> fail;
	    pick_up(Is, L, Part)).
pick_up([I|Is], Exp, Part):-
	simplify(and(not(I),Exp),L),
	(L = false -> fail;
	    pick_up(Is, L, Part)).

to_preint_([X,=,Y],(X,Y,Y)).
to_preint_([X,>=,Y],(X,Y,inf)).
to_preint_([X,>,Y],(X,Y1,inf)):-
	Y1 is Y+1.
to_preint_([X,=<,Y],(X,-inf,Y)).
to_preint_([X,<,Y],(X,-inf,Y1)):-
	Y1 is Y-1.

to_preint([>=,X,X],[],true) :- !.
to_preint([=<,X,X],[],true) :- !.
to_preint([=,X,X],[],true) :- !.
to_preint([>,X,X],[],false) :- !.
to_preint([<,X,X],[],false) :- !.
to_preint([N,X,Y],[X],I):-
	varname(X), number(Y), !, to_preint_([X,N,Y],I).
to_preint([N,X,Y],[Y],I):-
	number(X), varname(Y), !, to_preint_([Y,N,X],I).
to_preint([N,X,Y],[],I):- number(X), number(Y), !,
	S =.. [N,X,Y], (call(S) -> I = true; I = false).
to_preint([N,X,Y],L,S) :- vars(X,LX), vars(Y,LY),
	append(LX,LY,L0), sort(L0, L), S=.. [N,X,Y].

to_interval_(true, List,List).
to_interval_((Constr, Constraints), List, L):-
	Constr =.. [N,Arg1,Arg2],
	to_preint([N,Arg1,Arg2], Var, PreInt),
	\+ (PreInt = false),!,
	add_var_preint(List,Var,PreInt,List1),
	to_interval_(Constraints, List1, L).
to_interval(Constraints, Intervals):-
	to_interval_(Constraints, [], List),
	simplify_all(List, Intervals).
to_intervals(true, []).
to_intervals((Constraints,SequenceOfConstraints),Intervals):-
	(to_interval(Constraints,Interval) ->
	    to_intervals(SequenceOfConstraints, Intervals0),
	    interval_to_conjunct(Interval, Conjunct),
	    Intervals = [Conjunct|Intervals0]
	; to_intervals(SequenceOfConstraints, Intervals)).

interval_to_conjunct([I1,I2], and(I1,I2)):-!.
interval_to_conjunct([I1|I2], and(I1,I3)):-
	interval_to_conjunct(I2,I3).
interval_to_conjunct([I], I).
sequence_to_conjunct((B1,(B2,true)), and(B1,B2)):-!.
sequence_to_conjunct((B1,B2), and(B1,B3)):-
	sequence_to_conjunct(B2,B3).

add_var_preint(List,[],_,List):- !. % false was already removed, thus []=true
add_var_preint([],Var,PreInt,[Var-PreInt]):-!.
add_var_preint([Var-X|List],Var,PreInt,[Var-and(PreInt,X)|List]):- !.
add_var_preint([Var0-Exp0|List],Var,PreInt,[Var0-Exp0|NewList]) :-
	add_var_preint(List, Var, PreInt, NewList).

simplify_all([],[]).
simplify_all([[_]-Exp|List],[Exp1|NewList]):- !,
	simplify(Exp,Exp1),
	simplify_all(List, NewList).
simplify_all([[_,_|_]-Exp|List],[Exp|NewList]) :- !,
	simplify_all(List, NewList).
		   
partition(SequenceOfConstraints, Partition):-
	to_intervals(SequenceOfConstraints, Intervals),
	intervals_to_partition(Intervals, Partition).

%%%%%%% debugging
gen_test(N, Partition):-
	gen_test(1,N, Intervals),!,
	time(_),
	partition(Intervals, Partition),
	timer('Partitioning with findall ').
/*
gen_test(I,N,true) :- I >= N-I+1.
gen_test(I,N,(('#VAR'(J)>=I,'#VAR'(J)=<NI,true),Constraints)):-
	NI is N-I+1,I1 is I+1,
	random(0,I,J), 
	gen_test(I1, N, Constraints).
*/
gen_test(I,N,true) :- I >= N-I+1.
gen_test(I,N,(('#VAR'(J)>=I,'#VAR'(J)=<NI, J < N2, '#VAR'(J)>='#VAR'(0),'#VAR'(J)=<'#VAR'(I),true),Constraints)):-
	NI is N-I+1,I1 is I+1,
	N2 is NI - I,
	random(0,I,J), 
	gen_test(I1, N, Constraints).
%%%%%%%%%
