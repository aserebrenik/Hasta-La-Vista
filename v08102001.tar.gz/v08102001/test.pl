:- use_module(aux, [time/1, timer/1, up_to_n/2]).

main:- up_to_n(10000,L),
       time(_),
       mar(L,L,LL),
       timer('Rec '),
       man(L,L,LLL),
       timer('Nonrec ').

mar([], L, L).
mar([H|X],Y,[H|Z]):- mar(X,Y,Z).

man([], L, L).
