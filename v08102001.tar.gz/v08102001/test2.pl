:- use_module(library(clpq)).

go(Z):- %%%% X in 1..100, Y in 1..100,
        go1(X,Y),
	go2(X,Y,Z).
go1(X,Y):- {X > Y}.
go2(X,Y,Z):-
	entailed(X>Y) -> Z = 1 ; Z =0.
