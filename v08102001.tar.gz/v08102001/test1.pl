:- use_module(library(clpfd)).
:- use_module(library(clpq)).

go(Z):- %%%% X in 1..100, Y in 1..100,
        go1(X,Y),
	go2(X,Y, Z).
go1(X,Y):-
	Op =.. [#>,X,Y], 
	Op, {X>Y}.
go2(X,Y,Z):-
	Op =.. [#>, X, Y],
	(entailed(X>Y) -> write('Entailed') ; write('Not entailed')),
	M =.. [#<=>,Op,Z],
	M.