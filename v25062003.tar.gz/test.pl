p :-
	before, flag(Flag),
	l(X), r(Flag).

before.

flag(a).
flag(b).

l(0).
l(1).

r(a) :- write(a), fail.
r(b) :- write(b).