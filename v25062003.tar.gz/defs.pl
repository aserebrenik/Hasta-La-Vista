:- module(defs, [operators_file_name/1, output_file_name/1, type_analysis_working_directory/1]).

operators_file_name('''/home/alexande/aisys/rigidt/operator.pro''').
output_file_name('/home/alexande/aisys/adi/rtyt/output.pro').
type_analysis_working_directory('/home/alexande/aisys/adi/').
