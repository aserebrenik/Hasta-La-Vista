:- module(main, [main/4]).
:- use_module(adornments,[ads_main/11]).
:- use_module(adorn, [original_free_atom/3]).
:- use_module(atom, [fresh_all/2]).
:- use_module(aux, [all_unifiables/4, writel/1, timer/1]).
:- use_module(numvars, [diff_vars/2, frz/2, melt/2]).
%:- use_module(simplify_symb, [simplify_symb/2]).
:- use_module(intervals, [simplify/2]).
:- use_module(read_program, [read_program/2]).
:- use_module(termination, [prove_termination/8]).
:- use_module(type_inference, [type_inference/6]).
:- use_module(library(lists), [append/3, member/2]).
:- use_module(library(ordsets), [ord_subtract/3]).

:- dynamic norm/2.
:- dynamic lm/2.
:- dynamic size_exp/2.
:- dynamic io/1. % io((delete(X,Y,Z),[2],[1,3]))
:- dynamic bad_body/1.
:- dynamic bad_clause/1.

main(File, Query, Share, TerminationCondition):-
	read_program(File, Clauses_),
	timer('Reading '),
	type_inference(Clauses_, Query, Share, NewClauses, Calls, IO),
	timer('Type Inference '),
	filter_clauses(NewClauses, Calls, Clauses),
	loop(Clauses, Calls, IO, [], 1, TerminationCondition1),
	timer('Loop '),
	!, frz(TerminationCondition1,FTC),
	simplify_symb_l(FTC, Simplified),
	melt(Simplified, TerminationCondition2),
	adjust_to_calls(TerminationCondition2, Calls, TerminationCondition),
	output_the_results(TerminationCondition),
	clean_up,
	timer('Rest ').

% filtering is needed since there may be clauses in Clauses_
% that are not actually used, i.e., the corrresponding calls do
% not appear among the Calls

filter_clauses([], _, []).
filter_clauses([clause(Head,Body)|Clauses_], Calls,
	       [clause(Head,Body)|Clauses]):-
	fresh_all(Head, H), member(H, Calls), !,
	filter_clauses(Clauses_, Calls, Clauses).
filter_clauses([_|Clauses_], Calls, Clauses):-
	filter_clauses(Clauses_, Calls, Clauses).

loop(Clauses, Calls, IO, OldAssumptions, Iteration, TerminationCondition):-
	ads_main(Clauses, simple, Calls, IO,
		 AdornedClauses, AdornedCalls,
		 AdornedIO, MutRec, Preds, C1, C2),
	timer('Loop ADS '),
	%%% aux:writel(AdornedClauses),
	prove_termination(Preds, AdornedIO,
			  AdornedCalls, AdornedClauses,
			  MutRec, _Dictionary, Assumptions, Predicates), !,
	timer('Loop Termination Proof '),
	(Assumptions = false -> % suspect non-termination
	    all_false(Preds, AllFalse),
		construct_termination_condition(C1,AllFalse,Iteration,
					    TerminationCondition)
	;
	    (Assumptions = [] ->
		construct_termination_condition(C1,C2,Iteration,
					    TerminationCondition)
	    ;
		(fresh_variables(OldAssumptions, Assumptions) ->
		    update_clauses(Clauses, Predicates, NewClauses),
		    append(Assumptions, OldAssumptions, NewAssumptions),
		    Iteration1 is Iteration+1,
		    loop(NewClauses, Calls, IO, NewAssumptions,
			 Iteration1, TerminationCondition1),
		    construct_termination_condition(C1,TerminationCondition1,
						    Iteration,
						    TerminationCondition)
		
		;
		    construct_termination_condition(C1,C2,Iteration,
						    TerminationCondition)
		))).


output_the_results(TerminationCondition):-
	split_terminates_doesnt(TerminationCondition, Terminates, Doesnt),
	
	(\+ Terminates = [] -> 
	    write('Termination is established for the following calls: '),nl,
	    writel(Terminates), nl
	;
	    true),
	(\+ Doesnt = [] ->
	    write('The program may not terminate for the following calls:'),
	    nl, writel(Doesnt), nl
	;
	    true).

split_terminates_doesnt([], [], []).
split_terminates_doesnt([Pred-false|Preds], Terminates, [Pred|Doesnt]):-
	!, split_terminates_doesnt(Preds, Terminates, Doesnt).
split_terminates_doesnt([Pred-TC|Preds], [Pred-TC|Terminates], Doesnt):-
	split_terminates_doesnt(Preds, Terminates, Doesnt).

adjust_to_calls([], _, []).
adjust_to_calls([Predicate-Condition|TC1],
		Calls, TC2):-
	all_unifiables(Predicate,Calls,PCalls,Rest),
	adjust_to_calls(TC1, Rest, TC),
	append_conditioned(PCalls,Condition,TC,TC2).

append_conditioned([], _, L, L).
append_conditioned([PCall|PCalls],Condition,TC,[PCall-Condition|TC2]):-
	append_conditioned(PCalls,Condition,TC,TC2).

all_false(Preds, AllFalse):-
	all_false_(Preds, AF),
	sort(AF, AllFalse).
all_false_([], []).
all_false_([Predicate|Predicates], [OPredicate-false|C]):-
	original_free_atom(Predicate, OPredicate, _),
	all_false_(Predicates, C).

construct_termination_condition([],_,1,[]) :- !.
construct_termination_condition([P-Cond1|C1],C2,1,[P-or(Cond1,Cond2)|C]) :-
	!, member(P-Cond2, C2),
	construct_termination_condition(C1,C2,1,C).
construct_termination_condition(_,C2,I,C2) :- I > 1, !.
	

% fresh_variables is true if Expr2 has some variables that
% do not appear in Expr1
fresh_variables(Expr1, Expr2):-
	diff_vars(Expr1, Vars1), diff_vars(Expr2, Vars2),
	ord_subtract(Vars2, Vars1, [_|_]).

update_clauses([], _, []).
update_clauses([clause(Head,Body)|Clauses], Pred,
	       [clause(Head,(Condition1,Body))|Clauses1]):-
	member((Head,Condition), Pred),
	remove_dash(Condition, Condition1),
	update_clauses(Clauses, Pred, Clauses1).

remove_dash(X #> Y, X>Y).
remove_dash(X #< Y, X<Y).
remove_dash(X #= Y, X=Y).
remove_dash(X #>= Y, X>=Y).
remove_dash(X #=< Y, X=<Y).

simplify_symb_l([], []).
simplify_symb_l([P-Exp|Ps], [P-Exp2|P2s]):-
	simplify(Exp, Exp2),
	simplify_symb_l(Ps, P2s).


clean_up :-
	retractall(io(_)),
	retractall(norm(_,_)),
	retractall(lm(_,_)),
	retractall(size_exp(_,_)),
	retractall(bad_body(_)),
	retractall(bad_clause(_)).
/*

loop([clause(q(X,Y), (X>Y, Z is X-Y, Y1 is Y+1, q(Z,Y1), true))],
     [q(i1,i2)], [(q(_,_),[1,2],[])], TC).
loop([clause(p(X), (X>1,X<1000,X1 is -X*X,p(X1), true)),
      clause(p(X), (X< -1, X> -1000, X1 is X*X, p(X1), true))],
     [p(i)], [(p(_), [1], [])], TC).
loop([clause(p(X), (X<100, X1 is X+1, p(X1), true))],
     [p(i)], [(p(_), [1], [])], TC).
loop([clause(p(X), (X>1,Y is X*X,p(X,Y),true)),
      clause(p(X,Y), (X1 is X-1, p(X1), true))],
     [p(i), p(i1,i2)], [(p(_), [1], []), (p(_,_), [1,2], [])],
     TC).
loop([clause(p(X,Y), (Y>1, X is Y*Y, p(Y),true)),
      clause(p(X), (X1 is X-1, p(X1,Y), true))],
     [p(i), p(i1,i2)], [(p(_), [1], []), (p(_,_), [1,2], [])], TC).
loop([clause(p([X|Y],Z), (Z>0,Z1 is Z+1,p(Y,Z1),true))], 
     [p([_],i)], [(p(_,_), [1,2], [])], TC).
loop([clause(p(X), (X>0, X1 is X-1, p(X1), true))],
     [p(i)], [(p(_), [1], [])], TC).
loop([clause(delete(X,[X|T],T), true),
      clause(delete(X,[H|T],[H|T1]),
	     (delete(X,T,T1), true)),
      clause(permute([],[]), true),
      clause(permute(L, [El|T]),
	     (delete(El,L,L1), permute(L1,T), true))],
     [delete(_,[_],_), permute([_],_)],
     [(delete(_,_,_), [2], [1,3]),
	       (permute(_,_), [1], [2])], TC).
loop([clause(p, (p, true))], [p], [(p, [], [])], TC).

main('../examples/quicksort',
     quicksort('[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'),
     [], TC).
main('../examples/app',
     app('[T1 $= [] $| \'.\'(Int, T1)]','[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'),
     [], TC).
% non-termination is established for the following examples
main('../examples/app',
     app('[T2 $=MAX]','[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
main('../examples/app',
     app('[T2 $=MAX]','[T2 $=MAX]','[T2 $=MAX]'), [], TC).

main('../examples/permute',
     permute('[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'),
     [], TC).
main('../examples/perm_app',
     perm('[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'),
     [], TC).
main('../examples/zebra',
     zebra('[T1 $= MAX]', '[T1 $= MAX]', '[T1 $= MAX]'),
     [], TC).

% occur check!
main('../examples/strange',
     g, [], TC).


main('../examples/bad_append',
     app('[T1 $= [] $| \'.\'(Int, T1)]','[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'),
     [], TC).

% termination cannot be proved over {0,1}
main('../examples/various/ack', ack('[T1 $= 0 $| s(T1)]', '[T1 $=  0 $| s(T1)]', '[T2 $= MAX]'),
     [], TC).
% fails during the labeling
main('../examples/various/associative', normal_form('[T1 $= op(Int $| T1, Int $| T1)]', '[T2 $= MAX]'), [], TC).

main('../examples/various/credit', credit('[T1 $= Int]',  '[T2 $= MAX]'), [],
     TC).

main('../examples/dds/dds1.1', append('[T1 $= [] $| \'.\'(Int, T1)]','[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
main('../examples/dds/dds1.2', permute('[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
main('../examples/dds/dds3.13', duplicate('[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
main('../examples/dds/dds3.14', sum('[T1 $= [] $| \'.\'(Int, T1)]','[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
main('../examples/dds/dds3.15', merge('[T1 $= [] $| \'.\'(Int, T1)]','[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
%%% DOES NOT WORK - TYPE ANALYSIS LOOPS
main('../examples/dds/dds3.17', dis('[T2 $= 0 $| 1 $| or(T2,T2) $| and(T2,T2)]'), [], TC).
main('../examples/dds/dds3.8', reverse('[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]','[T2 $=MAX]'), [], TC).

%%%% TESTED
main('../examples/apt/list', list('[T1 $= [] $| \'.\'(Int, T1)]'), [], TC).
main('../examples/apt/fold', fold('[T1 $= Int]',  '[T1 $= [] $| \'.\'(Int, T1)]', '[T2 $=MAX]'), [], TC).
main('../examples/apt/lte', goal, [], TC).
main('../examples/apt/map', map('[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
main('../examples/apt/member', member('[T1 $= Int]',  '[T1 $= [] $| \'.\'(Int, T1)]'), [], TC).
% possibility of non-termination
main('../examples/apt/mergesort', mergesort('[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
main('../examples/apt/mergesort_ap', mergesort('[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]', '[T1 $= [] $| \'.\'(Int, T1)]'), [], TC).
main('../examples/apt/naive_rev', reverse('[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
main('../examples/apt/ordered', ordered('[T1 $= [] $| \'.\'(Int, T1)]'), [], TC).
main('../examples/apt/overlap', overlap('[T1 $= [] $| \'.\'(Int, T1)]','[T1 $= [] $| \'.\'(Int, T1)]'), [], TC).
main('../examples/apt/permutation', perm('[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
main('../examples/apt/quicksort', qs('[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
main('../examples/apt/select', select('[T2 $=MAX]', '[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
main('../examples/apt/subset', subset('[T1 $= [] $| \'.\'(Int, T1)]', '[T1 $= [] $| \'.\'(Int, T1)]'), [], TC).
% possibility of non-termination (true)
main('../examples/apt/subset', subset('[T2 $=MAX]', '[T1 $= [] $| \'.\'(Int, T1)]'), [], TC).
main('../examples/apt/sum', sum('[T2 $=MAX]', '[T2 $=MAX]', '[T1 $= 0 $| s(T1)]'), [], TC).


%%%% PLUEMER
% may not terminate (similar to DDV, in fact terminates)
main('../examples/plumer/mergesort_t', mergesort('[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
main('../examples/plumer/pl1.1', append('[T1 $= [] $| \'.\'(Int, T1)]','[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
main('../examples/plumer/pl1.1', append('[T2 $=MAX]','[T2 $=MAX]','[T1 $= [] $| \'.\'(Int, T1)]'), [], TC).
main('../examples/plumer/pl1.2',  perm('[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
% may not terminate - in fact does not terminate
main('../examples/plumer/pl2.3.1', p('[T1 $= Int]', '[T2 $=MAX]'), [], TC).
%%% PROBLEM - key already in use
main('../examples/plumer/pl3.1.1', a, [], TC).
% may not terminate - in fact does not terminate
main('../examples/plumer/pl3.5.6', p('[T2 $=MAX]'), [], TC).
main('../examples/plumer/pl3.5.6a', p('[T2 $=MAX]'), [], TC).
% may not terminate, in fact does not terminate, DDV used another version
main('../examples/plumer/pl4.01', append3('[T2 $=MAX]','[T2 $=MAX]','[T2 $=MAX]','[T1 $= [] $| \'.\'(Int, T1)]'), [], TC).
main('../examples/plumer/pl4.01a', append3('[T2 $=MAX]','[T2 $=MAX]','[T2 $=MAX]','[T1 $= [] $| \'.\'(Int, T1)]'), [], TC).
main('../examples/plumer/pl4.4.3', merge('[T1 $= [] $| \'.\'(Int, T1)]','[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
main('../examples/plumer/pl4.4.6a', perm('[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
% may not terminate, in fact does not terminate
main('../examples/plumer/pl4.5.2', s('[T1 $= Int $| +(T1, T1)]','[T2 $=MAX]'), [], TC).
main('../examples/plumer/pl4.5.3a', p('[T1 $= b]'), [], TC).
% may not terminate - indead does not
main('../examples/plumer/pl4.5.3a', p('[T1 $= a]'), [], TC).
%%% PROBLEM  - key already in use- empty
main('../examples/plumer/pl4.5.3b', goal, [], TC).
%%% PROBLEM - key already in use - empty
main('../examples/plumer/pl4.5.3c', goal, [], TC).
%%%%%%main('../examples/plumer/pl5.2.2', turing%%%%%%%%%%% how to call
main('../examples/plumer/pl6.1.1', qsort('[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
main('../examples/plumer/pl7.2.9', mult('[T1 $= 0 $| s(T1)]', '[T1 $=  0 $| s(T1)]', '[T2 $= MAX]'), [], TC).
% may not terminate - indead does not
main('../examples/plumer/pl7.6.2a', reach('[T1 $= Int]', '[T1 $= Int]', '[T1 $= [] $| \'.\'(\'.\'(Int, Int), T1)]'), [], TC).
% may not terminate - indead does not
main('../examples/plumer/pl7.6.2b', reach('[T1 $= Int]', '[T1 $= Int]', '[T1 $= [] $| \'.\'(\'.\'(Int, Int), T1)]', '[T1 $= [] $| \'.\'(Int, T1)]'), [], TC).
main('../examples/plumer/pl7.6.2c', reach('[T1 $= Int]', '[T1 $= Int]', '[T1 $= [] $| \'.\'(\'.\'(Int, Int), T1)]', '[T1 $= [] $| \'.\'(Int, T1)]'), [], TC).
% may not terminate (like DDV) - in fact terminates
main('../examples/plumer/pl8.2.1', mergesort('[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
% may not terminate - should terminate
main('../examples/plumer/pl8.2.1a', mergesort('[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
% may not terminate - should terminate
main('../examples/plumer/pl8.3.1', minsort('[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
main('../examples/plumer/pl8.3.1a', minsort('[T1 $= [] $| \'.\'(Int, T1)]','[T2 $=MAX]'), [], TC).
main('../examples/plumer/pl8.4.1', even('[T1 $= 0 $| s(T1)]'), [], TC).
main('../examples/plumer/pl8.4.1', odd('[T1 $= 0 $| s(T1)]'), [], TC).
% may not terminate - should take more complicated approach, p. 44 DDV
main('../examples/plumer/pl8.4.2', e('[T1 $= [] $| \'.\'(a $| b $| c $| \'+\' $| \'*\' $| \'(\' $| \')\', T1)]','[T2 $=MAX]'), [], TC).

main('../examples/various/game', win('[T1 $= [] $| \'.\'(Int, T1)]'), [], TC).


*/

