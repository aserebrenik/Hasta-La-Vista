:- module(
:- use_module(atom, [comparison/1, is_atom/1, substitute_atom/4]).
:- use_module(numvars, [melt/2, varlist/2, varname/1]).
:- use_module(intervals, [partition/2]).


partially_normalise_and_label(clause(Head,Body), IntArgPos,
		    clause(Head1,Body1)):-
	functor(Head, _, N), varlist(N,L),
	substitute_atom(Head, IntArgPos, L, Head1),
	Head =.. [_|Args], Head1 =.. [_|Args1],
	update_body(Args, Args1, Body, Body1).

:- meta_predicate update_body/4.
update_body([], [], B, B):- !.
update_body([Arg|Args], [Arg1|Args1], Body, Body1) :-
	(\+ varname(Arg1) ->
	    Body1 = Body0
	;
	    (var(Arg) ->
		Arg = Arg1, Body1 = Body0
	    ;
		Body1 = (Arg1 = Arg, Body0)
	    )
	),
	update_body(Args, Args1, Body, Body0).

get_maximal_prefix_candidate((Atom,Atoms), Algorithm, (Atom,Prefix)):-
	comparison(Atom), !,
	get_maximal_prefix_candidate(Atoms, Algorithm, Prefix).
get_maximal_prefix_candidate((Atom,Atoms), comp_is, (Atom,Prefix)):-
	is_atom(Atom), !,
	get_maximal_prefix_candidate(Atoms, comp_is, Prefix).
get_maximal_prefix_candidate((Atom,Atoms), terminates, (Atom,Prefix)):-
	terminates(Atom), !,
	get_maximal_prefix_candidate(Atoms, terminates, Prefix).
get_maximal_prefix_candidate(_, _Algorithm, true).

%%% intargpos - 
get_maximal_prefix(clause(_Head,Body), Algorithm, Prefix):-
	get_maximal_prefix_candidate(Body, Algorithm, Candidate),
	check_groundedness(Candidate, Prefix).

check_groundedness(true, true).
check_groundedness((C,Cs), (C,Ps)):-
	ground(C),!, check_groundedness(Cs,Ps).
check_groundedness(_, true).

get_maximal_prefixes([], true).
get_maximal_prefixes([Clause|Clauses], (Prefix, Prefixes)) :-
	get_maximal_prefix(Clause, comp, Prefix),
	get_maximal_prefixes(Clauses,Prefixes).

% section 4.2
find_adornments(Clauses, Adornments, simple):-
	get_maximal_prefixes(Clauses, Prefixes),!,
	partition(Prefixes, Adornments).

/*
partially_normalise(clause(p([X|Y],Z,5,Z), (Z>0,p(Y,Z,Z,Z),true)), [2,3,4], L),
     trace,
     find_adornments([L],Adornments).
*/