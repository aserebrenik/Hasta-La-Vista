:- module(rec, [rec/6]).

:- use_module(library(lists),[append/3, member/2]).
:- use_module(library(ordsets), [ord_subtract/3]).
:- use_module(atom, [built_in/1]).

% rec(Clauses, Rec, DirectRecursive, MutuallyRecursive, Nonrec, Unfoldable)
% divides predicates determined
% by Clauses to recursive ones and non-recursive ones

rec(Clauses, Rec, DR, MR, Nonrec, Unfoldable):-
	get_preds(Clauses, Preds, NDC),
	pairs(Clauses, Pairs, DirRec),
	times(Pairs, MutRec, FixPoint).

get_preds_([], [], []).
get_preds_([clause(H,B)|Clauses], Predss,NoDefPredsCandidatess):-
	functor(H,N,A),
	get_preds_(B,P),
	get_preds_(Clauses,Preds,NoDefPredsCandidates),
	append(P, NoDefPredsCandidates,NoDefPredsCandidatess), 
	append([N/A|P], Preds, Predss).
get_preds_(true, []).
get_preds_((B1,B2), Ps):-
	built_in(B1),!,
	get_preds_(B2,Ps).
get_preds_((B1,B2), [N/A|Ps]):-
	functor(B1,N,A),
	get_preds_(B2,Ps).

get_preds(C, P, NDC):- get_preds_(C, P_, NDC_),
	sort(P_, P), sort(NDC_, NDC0),
	ord_subtract(NDC0, P, NDC).

pairs_([], [], []).
pairs_([clause(H,B)|Clauses], Pairs, DirRec):-
	functor(H,N,A),
	pairs_(N/A,B,P,D),
	pairs_(Clauses, Pairs1, DirRec1),
	append(P, Pairs1, Pairs),
	append(D, DirRec1, DirRec).

pairs_(_, true, [], []).
pairs_(N/A, (B1,B2), P, D):-
	built_in(B1), !,
	pairs_(N/A, B2, P, D).
pairs_(N/A, (B1,B2), P, [N/A|D]):-
	functor(B1, N, A), !,
	pairs_(N/A, B2, P, D).
pairs_(N/A, (B1,B2), [(N/A, NB/AB,[NB/AB])|P], D):-
	functor(B1, NB, AB), 
	pairs_(N/A, B2, P, D).

pairs(Clauses, Pairs, DirRec):-
	pairs_(Clauses, P, D), sort(P, Pairs), sort(D, DirRec).

multiply(P1, P2, P):-
	multiply(P1, P2, P_, P1),
	sort(P_, P).
multiply([], [], [], _).
multiply([], [_|P2], P, P1) :-
	multiply(P1, P2, P, P1).
multiply([(A1,A2,L1)|P1], [(A2,A3,L2)|P2],
	 [(A1,A3,L)|P], P0):- !,
	append(L1,L2, L_),
	sort(L_, L),
	multiply(P1, [(A2,A3,L2)|P2], P, P0).
multiply([_|P1], P2, P3, P0):-
	multiply(P1, P2, P3, P0).

times(P, MutRec, FixPoint):-
	times(P, P, MutRec, FixPoint).

times(P1, P2, MutRec, FixPoint):-
	multiply(P1, P2, P),
	ord_subtract(P, P2, PRest),
	remove_loops(PRest, Loops, NoLoops),
	(NoLoops = [] ->
	    FixPoint = NoLoops, MutRec = Loops
	;
	    times(P1, NoLoops, MR, FP),
	    append(Loops, MR, MutRec),
	    append(NoLoops, FP, FixPoint)).

remove_loops([], [], []).
remove_loops([(N/A,N/A,L)|PRest], [(N/A,N/A,L)|Loops], NoLoops):-
	!, remove_loops(PRest, Loops, NoLoops).
remove_loops([(N/A,NB/AB,L)|PRest], Loops, [(N/A,NB/AB,L)|NoLoops]):-
	remove_loops(PRest, Loops, NoLoops).