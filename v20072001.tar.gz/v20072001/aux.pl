:- module(aux, [assert_list/2, combine/2, eliminate_duplicates/2,
		flatten/2, my_ord_subtract/3, my_ord_del_element/4, rename/4, 
		time/1, timer/1, without_last/2, writel/1]).

:- use_module(library(lists), [is_list/1]).
:- use_module(library(ordsets), [is_ordset/1, list_to_ord_set/2,ord_union/3]).
		      
assert_list(_,[]).
assert_list(F,[H|T]):-
	A=..[F,H],
	assertz(user:A),
	assert_list(F,T).

combine(Pos, Positions):-
	keysort(Pos, Pos1),
	combine_(Pos1,Positions).
combine_([],[]).
combine_([Pred-Pos1, Pred-Pos2|Pos], Positions):-
	!, to_ordset(Pos1, Pos11),
	to_ordset(Pos2, Pos21),
	ord_union(Pos11,Pos21,Pos3),
	combine_([Pred-Pos3|Pos], Positions).
combine_([Pred-Pos1|Pos], [Pred-Pos1|Positions]):-
	combine_(Pos, Positions).
to_ordset(OrdSet, OrdSet):-
	is_ordset(OrdSet), !.
to_ordset(List, OrdSet):-
	list_to_ord_set(List, OrdSet).

% eliminates repetitions from the list. f(X) and f(Y) are considered
% to be repetitions
eliminate_duplicates([],[]).
eliminate_duplicates([H|Elements], [H|Elements1]):-
	eliminate_duplicates(Elements, H, Elements1).
eliminate_duplicates([],_,[]).
eliminate_duplicates([H|T],H,L):-
	!, eliminate_duplicates(T,H,L).
eliminate_duplicates([X|T],_H,[X|L]):-
	eliminate_duplicates(T,X,L).

% flatten gets a recursive list and returns the non-list elements in it.
% for instance  flatten([1,[2,[3,4]],[5,[6,7]]],L)  returns
% L = [1,2,3,4,5,6,7] 

flatten(Xs,Ys) :- flatten_dl(Xs,d(Ys,[])).
flatten_dl([],d(Xs,Xs)).
flatten_dl([X|Xs],d(Ys,Zs)) :-
   flatten_dl(X,d(Ys,Ys1)),flatten_dl(Xs,d(Ys1,Zs)).
flatten_dl(X,d([X|Xs],Xs)) :- \+is_list(X), X\==[].

% following predicates are similar to ord_subtract and ord_del_element
% however, they remove element if it can be unified with the specified
% element (my_ord_del_element) or with an element of the specified list
% (my_ord_subtract)
my_ord_subtract(OrdSet, [], OrdSet).
my_ord_subtract(OrdSet, [E1|List], NewOrdSet):-
	my_ord_del_element(OrdSet,E1, OrdSet1, _),
	my_ord_subtract(OrdSet1, List, NewOrdSet).

my_ord_del_element([], _, [], []).
my_ord_del_element([El1|List], El2, OrdSet, [El1|List1]):-
	coincide(El1,El2),	  
	!, my_ord_del_element(List, El2, OrdSet, List1).
my_ord_del_element([X|List], El, [X|OrdSet], List1):-
	my_ord_del_element(List, El, OrdSet, List1).

coincide(E1,E2):-
	copy_term(E1,E11), copy_term(E2,E21), E11 = E21.

% rename(Old,New,OldTerm,NewTerm)
rename(Old,New,OldTerm,NewTerm):-
	OldTerm =.. OldList,
	rename_(Old,New,OldList,NewList),
	NewTerm =.. NewList.
rename_(_, _, [], []).
rename_(Old,New,[Old|OldList],[New|NewList]):-!,
	rename_(Old,New,OldList,NewList).
rename_(Old,New,[V|OldList],[NV|NewList]):-
	compound(V), !,
	rename(Old,New,V, NV), 
	rename_(Old,New,OldList,NewList).
rename_(Old,New,[V|OldList],[V|NewList]):-
	rename_(Old,New,OldList,NewList).
	
% information for timing
time(T) :- statistics(runtime,[_,Tmillisec]), T is Tmillisec/1000.

% debug predicate
timer(X) :- time(T),write(X),write(' '),write(T),nl.

without_last([X,_],[X]).
without_last([H|T],[H|T1]):- without_last(T,T1).

writel([]):- write('***********'), nl, nl.
writel([H|T]):- write(H), nl, writel(T).