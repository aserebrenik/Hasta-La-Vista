:- module(atom, [built_in/1, comparison/1, fresh_all/2,
		 is_atom/1, substitute_atom/4]).

comparison(_X = _Y).
comparison(_X < _Y).
comparison(_X =< _Y).
comparison(_X > _Y).
comparison(_X >= _Y).

is_atom(_X is _Y).

built_in(X):- is_atom(X).
built_in(X):- comparison(X).

substitute_atom(Atom, Positions, Values, NewAtom):-
	Atom =.. [Name|Arguments],
	substitute_args(Arguments, Positions, Values, 1, NewArguments),
	NewAtom =.. [Name|NewArguments].

substitute_args(Arguments, [], _, _I, Arguments) :- !.
substitute_args([Argument|Arguments], [I|Positions],
		Values, K, [Argument|NewArguments]) :-
	K < I, K1 is K+1,
	substitute_args(Arguments, [I|Positions], Values, K1, NewArguments).
substitute_args([_Argument|Arguments], [I|Positions],
		[Value|Values], I, [Value|NewArguments]) :-
	I1 is I+1,
	substitute_args(Arguments, Positions, Values, I1, NewArguments).

% fresh_all returns atom of the same functor but with all args - fresh vars
fresh_all(Atom, NewAtom):-
	functor(Atom, Name, Arity),
	functor(NewAtom, Name, Arity).