:- module(adornments,[get_maximal_prefix/3,main/5]).
:- use_module(adorn, [code/3, decode/3, original_free_atom/3]).
:- use_module(atom, [comparison/1, built_in/1,
		     substitute_atom/4, fresh_all/2]).
:- use_module(aux, [assert_list/2,combine/2,
		    my_ord_del_element/4,timer/1]).
:- use_module(check_clp,[check_clp/1]).
:- use_module(comma, [comma_eliminate_redundancy/2]).
:- use_module(numvars, [frz/2, melt/2, varlist/2, varname/1]).
:- use_module(intervals, [interval_to_conjunct/2, partition/3,
			  to_intervals/2, list_to_tree/3, simplify/2]).
:- use_module(find_int_pos, [find_int_pos/2]).
:- use_module(library(lists), [append/3,delete/3, member/2, nth0/3]).
:- use_module(library(ordsets), [list_to_ord_set/2, ord_subtract/3,
				 ord_union/3]).
:- use_module(rec, [rec/6]).

partially_normalise_and_label(clause(Head,Body), 
		    clause(Head1,Body1)):-
	fresh_all(Head, Head_),
	user:iap(Head_-IntArgPos),
	length(IntArgPos, N), varlist(N,L),
	substitute_atom(Head, IntArgPos, L, Head1),
	Head =.. [_|Args], Head1 =.. [_|Args1],
	update_body(Args, Args1, Body, Body1).
partially_normalise_and_label([],[]).
partially_normalise_and_label([C|Cs],[C1|Cs1]):-
	copy_term(C,C_),
	partially_normalise_and_label(C_,C1),
	partially_normalise_and_label(Cs,Cs1).

:- meta_predicate update_body/4.
update_body([], [], B, B):- !.
update_body([Arg|Args], [Arg1|Args1], Body, Body1) :-
	(\+ varname(Arg1) ->
	    Body1 = Body0
	;
	    (var(Arg) ->
		Arg = Arg1, Body1 = Body0
	    ;
		Body1 = (Arg1 = Arg, Body0)
	    )
	),
	update_body(Args, Args1, Body, Body0).

get_maximal_prefix_candidate((Atom,Atoms), Algorithm, (Atom,Prefix)):-
	comparison(Atom), !,
	get_maximal_prefix_candidate(Atoms, Algorithm, Prefix).
get_maximal_prefix_candidate((Atom,Atoms), built_in, (Atom,Prefix)):-
	built_in(Atom), !,
	get_maximal_prefix_candidate(Atoms, built_in, Prefix).
get_maximal_prefix_candidate((Atom,Atoms), terminates, (Atom,Prefix)):-
	terminates(Atom), !,
	get_maximal_prefix_candidate(Atoms, terminates, Prefix).
get_maximal_prefix_candidate(_, _Algorithm, true).

%%% intargpos - 
get_maximal_prefix(clause(Head,Body), Algorithm, (Head1,Prefix)):-
	fresh_all(Head,Head1),
	get_maximal_prefix_candidate(Body, Algorithm, Candidate),
	check_groundedness(Candidate, Prefix_),
	comma_eliminate_redundancy(Prefix_, Prefix).

check_groundedness(true, true).
check_groundedness((C,Cs), (C,Ps)):-
	ground(C),!, check_groundedness(Cs,Ps).
check_groundedness(_, true).

get_maximal_prefixes_([], _Algo, true).
get_maximal_prefixes_([Clause|Clauses], Algo, (Prefix, Prefixes)) :-
	get_maximal_prefix(Clause, Algo, Prefix),
	get_maximal_prefixes_(Clauses,Algo,Prefixes).
get_maximal_prefixes(Clauses, Algo, Prefixes):-
	get_maximal_prefixes_(Clauses, Algo, Prefixes_),!,
	comma_eliminate_redundancy(Prefixes_, Prefixes).

% section 4.2
find_adornments(Clauses, simple, Adornments):-
	get_maximal_prefixes(Clauses, comp, Prefixes),!,
	partition(Clauses, Prefixes, Adornments).

main(Clauses, Algorithm, Adornments, AdornedClauses, C1):-
	find_int_pos(Clauses, IntArgPos),
	%timer('IntPos :> '),
	retractall(user:iap(_)),
	assert_list(iap,IntArgPos),
	partially_normalise_and_label(Clauses, LClauses),
	%timer('PartNorm :> '),
	melt(LClauses, NewClauses),
	%timer('Melt :> '),
	find_adornments(LClauses, Algorithm, Adornments),
	%timer('Find Adornments :> '),
	get_maximal_prefixes(LClauses, built_in, Prefixes),
	%timer('Get Prefixes :> '),
	adorn_clauses(Adornments, NewClauses, Prefixes, AdornedClauses),
	%,timer('Adorn Clauses :> ')
	rec(AdornedClauses, Rec, _, _, NonRec, Unfoldable),
	ord_union(Rec,NonRec,Preds),
	no_preds(Preds,Adornments,NoPredsAdornments),
	compute_c_1(NoPredsAdornments,Unfoldable,C1).
/*
     main([clause(p([X|Y],Z), (Z>0,Z1 is Z+1,p(Y,Z1),true))], simple,
          AD, AC, C1).
     main([clause(p(X), (X>1,X<1000,X1 is -X*X,p(X1), true)),
           clause(p(X), (X< -1, X> -1000, X1 is X*X, p(X1), true))],
	   simple, AD, AC, C1).
     main([clause(q(X,Y), (X>Y, Z is X-Y, Y1 is Y+1, q(Z,Y), true))],
          simple, AD, AC, C1).
     main([clause(p(X), (X>1,Y is X*X,p(X,Y),true)),
           clause(p(X,Y), (X1 is X-1, p(X1), true))],
	  simple, AD, AC, C1).
     main([clause(p(X,Y), (Y>1, X is Y*Y, p(Y),true)),
           clause(p(X), (X1 is X-1, p(X1,Y), true))],
	  simple, AD, AC, C1).
*/

%% adorn_body(Body, Predicate, Adornments, NewBody) adorns the body
%% in all possible ways

adorn_body(true, _, true).
adorn_body((B1,B2), AllAdornments, (NB1,NB2)):-
	member(Predicate-Adornments, AllAdornments),
	fresh_all(B1,Predicate), !,
	member(Adornment, Adornments),
	B1 =.. [P|Arguments],
	code(P,Adornment,NewPredicate),
	NB1 =.. [NewPredicate|Arguments],
	adorn_body(B2, Adornments, NB2).
adorn_body((B1,B2), Adornments, (B1,NB2)):-
	adorn_body(B2, Adornments, NB2).

adorn_clause(clause(Head, Body), Adornments, Pref, clause(Head1, Body1)):-
	adorn_body((Head, true), Adornments, (Head1, true)),
	check_consistency1(Head1, Pref, Conjunction),
	adorn_body(Body, Adornments, Body1),
	check_consistency(Body1, Conjunction).

adorn_clauses(_, [], _, []).
adorn_clauses(Adornments, [Clause|Clauses], (Pref,Prefs), AdornedClauses):-
	findall(AClause, adorn_clause(Clause, Adornments, Pref, AClause),
		AClauses),
	adorn_clauses(Adornments, Clauses, Prefs, AdornedClauses0),
	append(AClauses, AdornedClauses0, AdornedClauses).

check_consistency1(Head, Prefix, and(PrConj, HeadConstraints)):-
	Head =.. [HeadPred|_],
	decode(HeadPred, _, Adornment),
	apply(Adornment, Head, HeadConstraints),
	to_intervals((Prefix, true), [_-[PrefixConj]]),
	apply(PrefixConj, Head, PrConj),
	check_clp(and(PrConj, HeadConstraints)).

check_consistency(Body, HPConj):-
	get_constraints(Body, Constraints),
	interval_to_conjunct(Constraints, Conj),
	check_clp(and(Conj, HPConj)).

get_constraints(true, []).
get_constraints((B1,B2), [Constr|Constrs]):-
	B1 =.. [B1Pred|_],
	decode(B1Pred, _P, Adornment), !,
	apply(Adornment, B1, Constr),
	get_constraints(B2, Constrs).
get_constraints((_B1,B2), Adornments):-
	get_constraints(B2, Adornments).


apply(or(LA1,LA2), Atom, or(A1,A2)):- !,
	apply(LA1,  Atom, A1),
	apply(LA2,  Atom, A2).
apply(and(LA1,LA2), Atom, and(A1,A2)):-!,
	apply(LA1,  Atom, A1),
	apply(LA2,   Atom, A2).
apply(not(LA1), Atom, not(A1)):-!,
	apply(LA1,  Atom, A1).
apply(LA1 = LA2,  Atom, A1 = A2):- !,
	apply(LA1,  Atom, A1),
	apply(LA2,  Atom, A2).
apply(LA1 >= LA2, Atom, A1 >= A2):- !,
	apply(LA1,   Atom, A1),
	apply(LA2,   Atom, A2).
apply(LA1 =< LA2,  Atom, A1 =< A2):- !,
	apply(LA1,   Atom, A1),
	apply(LA2,   Atom, A2).
apply(LA1 > LA2, Atom, A1 > A2):- !,
	apply(LA1,  Atom, A1),
	apply(LA2,  Atom, A2).
apply(LA1 < LA2, Atom, A1 < A2):- !,
	apply(LA1,   Atom, A1),
	apply(LA2,   Atom, A2).
apply(LA1 is LA2, Atom, A1 is A2):- !,
	apply(LA1,   Atom, A1),
	apply(LA2,   Atom, A2).
apply(LA1 + LA2, Atom, A1 + A2):- !,
	apply(LA1,   Atom, A1),
	apply(LA2,   Atom, A2).
apply(LA1 - LA2, Atom, A1 - A2):- !,
	apply(LA1,   Atom, A1),
	apply(LA2,   Atom, A2).
apply(LA1 * LA2, Atom, A1 * A2):- !,
	apply(LA1,   Atom, A1),
	apply(LA2,   Atom, A2).
apply(LA1 / LA2, Atom, A1 / A2):- !,
	apply(LA1,   Atom, A1),
	apply(LA2,   Atom, A2).
apply((LA1, A2, A3),  Atom, (A1, A2,A3)):- !,
	apply(LA1,   Atom, A1).
apply('#VAR'(K),  Atom, V):-
	!, original_free_atom(Atom, OAtom, _),
	user:iap(OAtom-IntArgPos),!,
	nth0(K, IntArgPos, ArgNo),
	arg(ArgNo, Atom, V).
apply(G, _, G):-
	ground(G).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

no_preds([], A, A).
no_preds([Pred|Preds],Adornments,NoPredsAdornments):-
	original_free_atom(Pred, OPred, UsedAd),
	my_ord_del_element(Adornments, OPred-Ads, NewAdornments, [OPred-Ads]),
	delete(Ads, UsedAd, Ads1),
	no_preds(Preds, [OPred-Ads1|NewAdornments],NoPredsAdornments).

preds_to_original_preds_and_adornments(AdornedPreds, List):-
	preds_to_original_preds_and_adornments_(AdornedPreds, List1),
	combine(List1, List).
preds_to_original_preds_and_adornments_([],[]).
preds_to_original_preds_and_adornments_([AP|APs], [P-[A]|PAs]):-
	original_free_atom(AP,P,A),
	preds_to_original_preds_and_adornments_(APs,PAs).

compute_c_1(NoPredsAdornments,Unfoldable, C1) :-
	preds_to_original_preds_and_adornments(Unfoldable,UnfoldableList),
	append(NoPredsAdornments,UnfoldableList,List),
	combine(List,Adornments),
	build_c_1(Adornments,C1).

build_c_1([], []).
build_c_1([Pred-Ads|Preds], [Pred-C1|C1s]):-
	list_to_tree(Ads,or,Tree),
	simplify(Tree, C1Var),
	apply(C1Var, Pred, C1),
	build_c_1(Preds,C1s).
	
