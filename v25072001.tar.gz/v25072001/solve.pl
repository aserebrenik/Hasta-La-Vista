:- module(solve, [solve/2]).

:- use_module(library(clpfd)).
:- use_module(library(lists), [append/3]).
:- use_module(numvars, [sym_melt/3, diff_vars/2]).
:- use_module(aux, [writel/1]).


solve(C,D) :-
	sym_melt(C,MC,D),
	diff_vars(MC, Vs),
	gr_eq(Vs),
	solve1(MC),
	labeling([],Vs),
	write(D),nl.

gr_eq([]).
gr_eq([V|Vs]):-
	V in 0..1,
	gr_eq(Vs).

solve1([]).
solve1([X|Xs]):-
	!, X,
	solve1(Xs).


