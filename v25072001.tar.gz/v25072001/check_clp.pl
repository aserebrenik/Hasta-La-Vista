:- module(check_clp, [check_clp/1]).
:- use_module(library(clpq)).

check_clp(true) :- !.
check_clp(false) :- fail.
check_clp((_X,-inf,inf)):-!.
check_clp((X,Min,inf)):- !, {X >= Min}.
check_clp((X,-inf,Max)):- !, {X =< Max}.
check_clp((X,Min,Max)):- {X >= Min, X =< Max}.
check_clp(X is Y) :- {X = Y}.
check_clp(X = Y)  :- {X = Y}.
check_clp(X > Y)  :- {X > Y}.
check_clp(X >= Y) :- {X >= Y}.
check_clp(X < Y)  :- {X < Y}.
check_clp(X =< Y) :- {X =< Y}.
check_clp(and(X1,X2)):-
	check_clp(X1), check_clp(X2).
check_clp(or(X1,_X2)):-
	check_clp(X1), !.
check_clp(or(_X1,X2)):-
	check_clp(X2), !.
check_clp(not(X1)):-
	\+ check_clp(X1).